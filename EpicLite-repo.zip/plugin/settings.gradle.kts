rootProject.name = "EpicLite"
